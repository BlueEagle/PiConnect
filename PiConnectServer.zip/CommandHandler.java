import java.util.*;
import java.awt.*;
import java.awt.event.*;

public class CommandHandler {
	private static String volumeIncrementSize = "5000";
	
	public static String[] breakCommand(String cmd) {
		ArrayList<String> cmdArrayList = new ArrayList<String>(); //  creates an array to fill
		int lastIndex = 0;
		for (int i = 0; i < cmd.length(); i++) {
			if(cmd.charAt(i) == 32) {
				cmdArrayList.add(cmd.substring(lastIndex, i)); // adds the thing...
				lastIndex = i+1;
			}
		}
		cmdArrayList.add(cmd.substring(lastIndex, cmd.length()));
		String[] cmdArray = new String[cmdArrayList.size()];
		int ph = 0;
		for (String s:cmdArrayList) {
			cmdArray[ph] = s;
			ph++;
		}
		return cmdArray;
	}
	
	public static void execute(String[] args) { // handles the command issued to the server
		if (args.length >= 1) {  // vvv Handles any number of arguments vvv
			if (args.length == 1) try1ArgCommands(args);
			else if (args.length == 2) try2ArgCommands(args);
			else if (args.length == 3) try3ArgCommands(args);
			else if (args.length == 4) try4ArgCommands(args);
		} else {
			System.err.println("Not a valid command.");
		}
	}
	
	// COMMAND ARGUMENT CHANNELER
	private static void try1ArgCommands(String[] args) {
		if (args[0].toLowerCase().equals("volume_up")) {
			volume_up();
			return;
		}
		if (args[0].toLowerCase().equals("volume_down")) {
			volume_down();
			return;
		}
		if (args[0].toLowerCase().equals("mute")) {
			mute("1");
			return;
		}
		if (args[0].toLowerCase().equals("unmute")) {
			mute("0");
			return;
		}
		if (args[0].toLowerCase().equals("kill")) {
			kill();
			return;
		}
		cmdLine(args[0]);
		return;
	}
	private static void try2ArgCommands(String[] args) {
		if (args[0].toLowerCase().equals("volume")) { // VOLUME <controls>
			if (args[1].toLowerCase().equals("up")) {
				volume_up();
				return;
			}
			if (args[1].toLowerCase().equals("down")) {
				volume_down();
				return;
			}
		}
		if (args[0].toLowerCase().equals("start")) { // START <program>
			if(args[1].toLowerCase().equals("pandora")) {
				startPandora();
				return;
			}
		}
		if (args[0].toLowerCase().equals("toggle")) { // TOGGLE <property>
			if (args[1].toLowerCase().equals("mute")) {
				mute("2");
				return;
			}
			if (args[1].toLowerCase().equals("pandora")) {
				togglePandora();
				return;
			}
		}
		if (args[0].toLowerCase().equals("skip")) { // SKIP <service>
			if(args[1].toLowerCase().equals("pandora")) {
				skipPandora();
				return;
			}
		}
		cmdLine(args[0], args[1]);
		return;
	}
	private static void try3ArgCommands(String[] args) {
		if (args[0].toLowerCase().equals("volume")) { // VOLUME <property> <value>  ***MAX VOLUME = 65535
			if (args[1].toLowerCase().equals("up")) {
				volume_up(args[2]);
				return;
			}
			if (args[1].toLowerCase().equals("down")) {
				volume_down(args[2]);
				return;
			}
		}
		if (args[0].toLowerCase().equals("set")) { // SET <property> <value>
			if (args[1].toLowerCase().equals("volume")) {
				set_volume(args[2]);
				return;
			}
		}
		cmdLine(args[0], args[1], args[2]);
		return;
	}
	private static void try4ArgCommands(String[] args) {
		cmdLine(args[0], args[1], args[2], args[3]);
		return;
	}
	
	// FUNCTION CONTROLS
	public static void volume_up() {
		try {
			Process p = new ProcessBuilder("nircmd.exe","changesysvolume", volumeIncrementSize).start();
			System.out.println("Volume level increased!");
		} catch (Exception e) {
			System.err.println("Error: " + e);
		}
	}
	public static void volume_up(String value) {
		value = Math.abs(Integer.parseInt(value)) + "";
		try {
			Process p = new ProcessBuilder("nircmd.exe","changesysvolume", value).start();
			System.out.println("Volume level increased by " + value + "!");
		} catch (Exception e) {
			System.err.println("Error: " + e);
		}
	}
	public static void volume_down() {
		try {
			Process p = new ProcessBuilder("nircmd.exe","changesysvolume", (Integer.parseInt(volumeIncrementSize) * -1)+"").start();
			System.out.println("Volume level decreased!");
		} catch (Exception e) {
			System.err.println("Error: " + e);
		}
	}
	public static void volume_down(String value) {
		value = (Math.abs(Integer.parseInt(value))*-1) + "";
		try {
			Process p = new ProcessBuilder("nircmd.exe","changesysvolume", value).start();
			System.out.println("Volume level decreased by " + value + "!");
		} catch (Exception e) {
			System.err.println("Error: " + e);
		}
	}
	public static void set_volume(String value) {
		try {
			Process p = new ProcessBuilder("nircmd.exe","setsysvolume", value).start();
			System.out.println("Volume level set to: " + value + "!");
		} catch (Exception e) {
			System.err.println("Error: " + e);
		}
	}
	public static void mute(String value) {
		try {
			Process p = new ProcessBuilder("nircmd.exe","mutesysvolume", value).start();
			if (value.equals("0")) System.out.println("Volume unmuted!");
			if (value.equals("1")) System.out.println("Volume muted!");
			if (value.equals("2")) System.out.println("Volume mute toggled!");
		} catch (Exception e) {
			System.err.println("Error: " + e);
		}
	}
	public static void kill() {
		System.out.println("Bye!");
		System.exit(-1);
	}
	public static void cmdLine(String arg1) {
		try {
			Process p = new ProcessBuilder(arg1).start();
			System.out.println("Command Executed!");
		} catch (Exception e) {
			System.err.println("Error: " + e);
		}
	}
	public static void cmdLine(String arg1, String arg2) {
		try {
			Process p = new ProcessBuilder(arg1, arg2).start();
			System.out.println("Command Executed!");
		} catch (Exception e) {
			System.err.println("Error: " + e);
		}
	}
	public static void cmdLine(String arg1, String arg2, String arg3) {
		try {
			Process p = new ProcessBuilder(arg1, arg2, arg3).start();
			System.out.println("Command Executed!");
		} catch (Exception e) {
			System.err.println("Error: " + e);
		}
	}
	public static void cmdLine(String arg1, String arg2, String arg3, String arg4) {
		try {
			Process p = new ProcessBuilder(arg1, arg2, arg3, arg4).start();
			System.out.println("Command Executed!");
		} catch (Exception e) {
			System.err.println("Error: " + e);
		}
	}
	public static void startPandora() {
		try {
			Robot robot = new Robot();
			robot.mouseMove(28, 1062);
			robot.mousePress(InputEvent.BUTTON1_MASK);
			robot.mouseRelease(InputEvent.BUTTON1_MASK);
			robot.keyPress(KeyEvent.VK_G);
			robot.keyPress(KeyEvent.VK_O);
			robot.delay(100);
			robot.keyPress(KeyEvent.VK_O);
			robot.keyPress(KeyEvent.VK_G);
			robot.keyPress(KeyEvent.VK_L);
			robot.keyPress(KeyEvent.VK_E);
			robot.keyPress(KeyEvent.VK_SPACE);
			robot.keyPress(KeyEvent.VK_C);
			robot.keyPress(KeyEvent.VK_H);
			robot.keyPress(KeyEvent.VK_R);
			robot.keyPress(KeyEvent.VK_O);
			robot.keyPress(KeyEvent.VK_M);
			robot.keyPress(KeyEvent.VK_E);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.delay(2000);
			robot.keyPress(KeyEvent.VK_P);
			robot.keyPress(KeyEvent.VK_A);
			robot.keyPress(KeyEvent.VK_N);
			robot.keyPress(KeyEvent.VK_D);
			robot.keyPress(KeyEvent.VK_O);
			robot.keyPress(KeyEvent.VK_R);
			robot.keyPress(KeyEvent.VK_A);
			robot.keyPress(KeyEvent.VK_PERIOD);
			robot.keyPress(KeyEvent.VK_C);
			robot.keyPress(KeyEvent.VK_O);
			robot.keyPress(KeyEvent.VK_M);
			robot.keyPress(KeyEvent.VK_ENTER);
			System.out.println("Pandora started!");
		} catch (Exception e) {
			System.err.println("Error: " + e);
		}
	}
	public static void togglePandora() {
		try {
			Robot robot = new Robot();
			robot.mouseMove(941, 115);
			robot.mousePress(InputEvent.BUTTON1_MASK);
			robot.mouseRelease(InputEvent.BUTTON1_MASK);
		} catch (Exception e) {
			System.err.println("Error: " + e);
		}
	}
	public static void skipPandora() {
		try {
			Robot robot = new Robot();
			robot.mouseMove(1010, 115);
			robot.mousePress(InputEvent.BUTTON1_MASK);
			robot.mouseRelease(InputEvent.BUTTON1_MASK);
		} catch (Exception e) {
			System.err.println("Error: " + e);
		}
	}
	
}